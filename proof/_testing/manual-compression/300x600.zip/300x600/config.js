const code = null

var rating

// Age Rating Controls
const sameLegal = false

const legal1 = rating
const legal2 = rating
const legal3 = rating
const legal4 = (code=="it_IT") ? rating : false
const legalEnd = rating

//endframe layout controls
var GamesY = rating? -85 : -72
var gamesDist = rating? 102 : 106
var gameDiscountDist = 44
